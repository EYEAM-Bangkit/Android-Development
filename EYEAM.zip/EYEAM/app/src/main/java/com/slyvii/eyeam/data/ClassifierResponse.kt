package com.slyvii.eyeam.data

import com.google.gson.annotations.SerializedName

data class ClassifierResponse(

	@field:SerializedName("animalName")
	val animalName: String? = null
)
