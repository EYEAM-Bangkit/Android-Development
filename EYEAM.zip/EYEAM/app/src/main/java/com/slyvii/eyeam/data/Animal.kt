package com.slyvii.eyeam.data

data class Animal(
    var id: Int?=null,
    var name: String="",
    var image: Int?=null
)
